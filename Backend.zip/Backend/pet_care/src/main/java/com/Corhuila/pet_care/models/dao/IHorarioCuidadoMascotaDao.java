package com.Corhuila.pet_care.models.dao;

import com.Corhuila.pet_care.models.entity.HorarioCuidadoMascota;
import org.springframework.data.repository.CrudRepository;

public interface IHorarioCuidadoMascotaDao extends CrudRepository<HorarioCuidadoMascota, Long> {
}
