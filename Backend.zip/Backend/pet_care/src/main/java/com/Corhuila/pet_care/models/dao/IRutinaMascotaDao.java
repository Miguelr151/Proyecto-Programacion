package com.Corhuila.pet_care.models.dao;

import com.Corhuila.pet_care.models.entity.RutinaMascota;
import org.springframework.data.repository.CrudRepository;

public interface IRutinaMascotaDao extends CrudRepository<RutinaMascota, Long> {
}
